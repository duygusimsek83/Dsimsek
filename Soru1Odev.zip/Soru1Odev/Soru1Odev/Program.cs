﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru1Odev
{
    internal class Program
    {
        static int SayiYazma(string girisi)
        {
            string sayilar = string.Empty;
            foreach (char c in girisi)
            {
                if (char.IsDigit(c))
                {
                    sayilar += c;
                }
            }
            return sayilar == string.Empty ? 0 : int.Parse(sayilar);
        }

        static void Main(string[] args)
        {

            Console.WriteLine("Bir yazı giriniz:");
            string KullaniciGirisi = Console.ReadLine();


            int sonuc = SayiYazma(KullaniciGirisi);


            Console.WriteLine($"Girilen yazı içindeki rakamların oluşturduğu sayı: {sonuc}");

            Console.ReadKey();
        }

    }
}
