﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru2Odev
{
    internal class Program
    {
        static int SesliHarfSayar(string giris)
        {
            char[] sesliharf = { 'a', 'e', 'i', 'ı' , 'ö' , 'ü' , 'o', 'u', 'A', 'E', 'İ', 'I' , 'Ö' , 'Ü' , 'O', 'U' };
            int sayim = 0;

            foreach (char c in giris)
            {
                if (Array.Exists(sesliharf, sesli => sesli == c))
                {
                    sayim++;
                }
            }
            return sayim;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Bir yazı giriniz:");
            string yazi = Console.ReadLine();

            int SesliSayar = SesliHarfSayar(yazi);

            Console.WriteLine($"Girilen yazı icindeki sesli harfler sayısı {SesliSayar}:");

            Console.ReadKey();
        }

    }
}
